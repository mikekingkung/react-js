import React from 'react';
import './css/AweSomeFooter.css';

function AweSomeFooter() {
    return (
      <div>
        <div>
          <header className="nav">Hello Footer</header>
        </div>
      </div>
    );
  }

  export default AweSomeFooter;
